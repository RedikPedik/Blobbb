# Mutant Blobs Attack – unofficial port (Godot 4.3 project)

Status: **written and statically checked, never run in Godot, no APK built yet.** See "What is verified" below.

## Build the APK from a phone (GitHub Actions, no PC)
1. In the phone browser open github.com, create a new repository (private is fine).
2. Add file → Create new file. Name it exactly `.github/workflows/build-apk.yml` and paste the contents of `build-apk.yml` (supplied next to this zip). Commit.
3. Add file → Upload files. Upload `mba_port.zip` (keep that exact name) to the repo root. Commit. The build starts by itself.
4. Open the Actions tab → "Build APK". When it is green (a few minutes), open the run and download the artifact `MutantBlobsPort-debug-apk`.
5. Unzip it, open `MutantBlobsPort.apk`, allow "install unknown apps" for your file manager or browser, install.
If a step goes red, open it and send me the red lines of the log.

## Build on a PC
Install Godot 4.3, the 4.3 export templates, JDK 17 and the Android SDK (platform-tools, build-tools 34.0.0, platform android-34), set their paths under Editor → Editor Settings → Export → Android, then Project → Export → Android → Export Project (debug). Or run the same steps as the workflow.

## What is in the game
Main menu (Story Mode, Options, Leaderboards = local bests, Quit on desktop only), 3 levels, pause/retry/next overlays, HUD (health bar, coin counter, blob counter, hint panel), multitouch controls (left half = floating joystick; jump, dash and magnet buttons on the right) and keyboard controls for desktop testing.
Gameplay is an ORIGINAL simple platformer core: eat crates to grow and heal, avoid spikes, collect coins, rescue all blobs, reach the exit.

## What is NOT in it
No original levels, physics values, enemies, blob sprite, music, sound or cutscenes were supplied, so none exist here. The blob is drawn with code (placeholder, `scripts/player.gd`). Tuning values are uncalibrated. The Cutscenes button, scan and rocket buttons were left out because nothing backs them.

## Files
- `project.godot`, `main.tscn`, `export_presets.cfg` – project and Android export preset (arm64-v8a, debug-signed).
- `scripts/` – all game code (`level_data.gd` = level layouts, `player.gd` = movement constants, `controls.gd` = touch/keyboard).
- `assets/ui/` – sprites cut from your sheets by `tools/slice_assets.py` (needs pillow, numpy, scipy). `scripts/ui_meta.gd` holds the health-bar pixel numbers the script measured.
- `.github/workflows/build-apk.yml` – cloud build.

## What is verified
Done: sprite slicing run and visually checked; level layouts checked by script (all surfaces reachable with jump limits derived from player.gd, no pickup inside terrain or spikes); GDScript brackets balanced, no tab/space mixing; workflow YAML parses.
Not done: opening the project in Godot (a GDScript error may still exist), the CI build, running on a phone.

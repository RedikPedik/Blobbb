"""Cuts the UI sprite sheets you supplied into single PNGs under assets/ui and
writes scripts/ui_meta.gd with the pixel numbers measured from the health bar.
Usage: python tools/slice_assets.py <sheet_transparent.png> <sheet_dark.png> <logo.png> <menu_bg.jpg>
Needs: pillow, numpy, scipy."""
import sys
from pathlib import Path
import numpy as np
from PIL import Image
from scipy import ndimage as ndi

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "assets" / "ui"
OUT.mkdir(parents=True, exist_ok=True)

# name -> (x, y) of the component's bbox top-left, measured on the 1672x941 sheets
SHEET_A = {  # transparent sheet
    "btn_play": (9, 16), "btn_story": (518, 18), "btn_options": (1003, 17),
    "btn_leaderboards": (10, 160), "btn_cutscenes": (517, 160), "btn_quit": (1002, 160),
    "btn_resume": (8, 307), "btn_menu": (344, 308), "btn_retry": (642, 309), "btn_back": (939, 308),
    "btn_next": (15, 451), "btn_select": (344, 451), "btn_accept": (649, 450), "btn_cancel": (938, 450),
    "ico_sound": (22, 590), "ico_music": (240, 588), "ico_fullscreen": (440, 590),
    "ico_help": (640, 592), "ico_settings": (838, 591), "ico_trophy": (1030, 591),
    "hint_panel": (1223, 757), "bar_src": (27, 761), "coin_src": (689, 777), "blobcount_src": (982, 777),
}
SHEET_B = {  # dark-background sheet, colour-keyed
    "blob_play": (41, 38), "blob_pause": (449, 19), "blob_resume": (769, 23),
    "blob_menu": (1081, 28), "blob_retry": (1377, 26), "blob_exit": (618, 302),
    "ico_mute": (1137, 307), "joy_knob": (130, 577), "jump_btn": (1419, 533),
    "dash_btn": (437, 514), "magnet_btn": (805, 555), "scan_btn": (1022, 555), "rocket_btn": (1227, 565),
}

def pick(objs, xy):
    best = min(range(len(objs)), key=lambda i: (objs[i][1].start - xy[0]) ** 2 + (objs[i][0].start - xy[1]) ** 2)
    d = (objs[best][1].start - xy[0]) ** 2 + (objs[best][0].start - xy[1]) ** 2
    if d > 20 ** 2:
        raise SystemExit(f"no component near {xy} (closest is {d ** .5:.0f}px away)")
    return best + 1

def cut(arr, lab, idx, objs, keep_alpha, mask_fn=None):
    sl = objs[idx - 1]
    reg = lab[sl] == idx
    reg = ndi.binary_fill_holes(reg)
    crop = arr[sl].copy()
    if keep_alpha:
        crop[..., 3] = np.where(reg, crop[..., 3], 0)
    else:
        reg = ndi.binary_erosion(reg, iterations=2)
        crop[..., 3] = np.where(reg, 255, 0)
    return crop

def sheet_a(path):
    arr = np.array(Image.open(path).convert("RGBA"))
    lab, _ = ndi.label(ndi.binary_dilation(arr[..., 3] > 40, iterations=2))
    objs = ndi.find_objects(lab)
    out = {}
    for name, xy in SHEET_A.items():
        out[name] = cut(arr, lab, pick(objs, xy), objs, True)
    return out

def sheet_b(path):
    arr = np.array(Image.open(path).convert("RGBA")).astype(int)
    rgb = arr[..., :3]
    m = (rgb.max(2) > 120) | ((rgb.max(2) - rgb.min(2)) > 70)
    m = ndi.binary_dilation(ndi.binary_opening(m, iterations=2), iterations=4)
    lab, _ = ndi.label(m)
    objs = ndi.find_objects(lab)
    arr = arr.astype(np.uint8)
    out = {}
    for name, xy in SHEET_B.items():
        out[name] = cut(arr, lab, pick(objs, xy), objs, False)
    return out

def save(name, a):
    Image.fromarray(a).save(OUT / f"{name}.png")

def icon_from_pill(src, left_frac):
    """Pull the bright icon out of a dark counter pill (text is to the right, dropped)."""
    h, w = src.shape[:2]
    reg = src[:, : int(w * left_frac)].astype(int)
    m = (reg[..., :3].max(2) > 110) & (reg[..., 3] > 100)
    m = ndi.binary_opening(m, iterations=1)
    lab, n = ndi.label(ndi.binary_dilation(m, iterations=2))
    sizes = ndi.sum(m, lab, range(1, n + 1))
    keep = lab == (int(np.argmax(sizes)) + 1)
    ys, xs = np.where(keep)
    crop = src[ys.min():ys.max() + 1, xs.min():xs.max() + 1].copy()
    crop[..., 3] = np.where(keep[ys.min():ys.max() + 1, xs.min():xs.max() + 1], crop[..., 3], 0)
    return crop

def build_bar(bar):
    """Split the baked health bar into: empty frame + fill strip. Returns meta."""
    h, w = bar.shape[:2]
    y = h // 2 + 8
    FILL = (191, 230, 7)
    fill = (abs(bar[..., 0].astype(int) - FILL[0]) < 14) & (abs(bar[..., 1].astype(int) - FILL[1]) < 14) & (bar[..., 2] < 40) & (bar[..., 3] > 200)
    fill[:, : 180] = False
    fill = ndi.binary_opening(fill, iterations=2)
    lab, n = ndi.label(fill)
    sizes = ndi.sum(fill, lab, range(1, n + 1))
    fill = lab == (int(np.argmax(sizes)) + 1)
    ys, xs = np.where(fill)
    x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    def is_empty(xx, yy):
        px = bar[yy, xx]
        return px[3] > 200 and px[0] < 90 and px[1] < 100 and px[2] < 40
    start = x1
    while start < w and not is_empty(start, y):
        start += 1
    end = start
    while end < w and is_empty(end, y):
        end += 1
    if start >= w or end - start < 10:
        raise SystemExit("could not locate the empty track of the health bar")
    sample_x = start + (end - start) // 2
    empty = bar.copy()
    for yy in range(y0, y1):
        empty[yy, x0:start] = bar[yy, sample_x]
    strip = bar[y0:y1, x0:end].copy()
    for yy in range(strip.shape[0]):
        strip[yy, x1 - x0:] = strip[yy, x1 - x0 - 6]
    inner_x1 = end
    return empty, strip, dict(BAR_W=w, BAR_H=h, STRIP_X=int(x0), STRIP_Y=int(y0), STRIP_W=int(inner_x1 - x0), STRIP_H=int(y1 - y0), FILL_AT_SOURCE_W=int(x1 - x0))

def main():
    if len(sys.argv) != 5:
        raise SystemExit(__doc__)
    a_path, b_path, logo_path, bg_path = sys.argv[1:]
    A, B = sheet_a(a_path), sheet_b(b_path)
    for name, arr in {**A, **B}.items():
        if name.endswith("_src"):
            continue
        save(name, arr)
    empty, strip, meta = build_bar(A["bar_src"])
    save("bar_empty", empty); save("bar_fill", strip)
    save("ico_coin", icon_from_pill(A["coin_src"], 0.34))
    save("ico_blob", icon_from_pill(A["blobcount_src"], 0.40))

    logo = Image.open(logo_path).convert("RGB")
    la = np.array(logo).astype(int)
    alpha = np.where(la.max(2) > 40, 255, 0).astype(np.uint8)
    alpha = ndi.binary_closing(alpha > 0, iterations=3)
    alpha = ndi.binary_fill_holes(alpha)
    lg = np.dstack([np.array(logo), (alpha * 255).astype(np.uint8)])
    ys, xs = np.where(alpha)
    Image.fromarray(lg[ys.min():ys.max() + 1, xs.min():xs.max() + 1]).save(OUT / "logo.png")

    bg = Image.open(bg_path).convert("RGB")
    bg.save(OUT / "menu_reference.png")  # screenshot of the original menu, reference only, not used in game

    lines = ["# Generated by tools/slice_assets.py from the supplied bar sprite. Pixel units in bar_empty.png / bar_fill.png.",
             ""]
    lines += [f"const {k} := {v}" for k, v in meta.items()]
    (ROOT / "scripts").mkdir(exist_ok=True)
    (ROOT / "scripts" / "ui_meta.gd").write_text("\n".join(lines) + "\n")
    print(meta)

main()

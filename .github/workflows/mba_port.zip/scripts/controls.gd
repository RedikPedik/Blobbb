extends Control
# One input source for the player: on-screen multitouch controls on phones, keyboard on desktop.
# Keyboard: A/D or arrows = move, Space/W/Up = jump, Shift/E = dash, Q = magnet, Esc/P = pause.

signal jump_down
signal dash_down
signal magnet_down
signal pause_down

const Ui = preload("res://scripts/ui.gd")

const JOY_RADIUS := 110.0
const DEADZONE := 0.2
const JUMP_R := 95.0
const DASH_R := 68.0
const MAGNET_R := 62.0
const PAUSE_R := 44.0
const HIT_SLOP := 14.0

var axis: float = 0.0
var jump_held: bool = false
var player = null            # optional, only read to dim buttons while on cooldown

var _show_touch: bool = false
var _touch_axis: float = 0.0
var _jump_touch: bool = false
var _jump_finger: int = -1
var _dash_finger: int = -1
var _magnet_finger: int = -1
var _pause_finger: int = -1
var _joy_finger: int = -1
var _joy_origin := Vector2.ZERO
var _joy_pos := Vector2.ZERO


func _ready() -> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    _show_touch = OS.has_feature("mobile") or DisplayServer.is_touchscreen_available()


func reset() -> void:
    _jump_finger = -1
    _dash_finger = -1
    _magnet_finger = -1
    _pause_finger = -1
    _joy_finger = -1
    _touch_axis = 0.0
    _jump_touch = false
    axis = 0.0
    jump_held = false


func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
        reset()


func _jump_c() -> Vector2:
    return Vector2(size.x - 150.0, size.y - 150.0)


func _dash_c() -> Vector2:
    return Vector2(size.x - 345.0, size.y - 105.0)


func _magnet_c() -> Vector2:
    return Vector2(size.x - 120.0, size.y - 335.0)


func _pause_c() -> Vector2:
    return Vector2(size.x - 70.0, 70.0)


func _idle_joy_c() -> Vector2:
    return Vector2(190.0, size.y - 170.0)


func _hit(pos: Vector2, c: Vector2, r: float) -> bool:
    return pos.distance_to(c) <= r + HIT_SLOP


func _input(event: InputEvent) -> void:
    if event is InputEventKey:
        var k := event as InputEventKey
        if k.pressed and not k.echo:
            match k.physical_keycode:
                KEY_SPACE, KEY_W, KEY_UP:
                    jump_down.emit()
                KEY_SHIFT, KEY_E:
                    dash_down.emit()
                KEY_Q:
                    magnet_down.emit()
                KEY_ESCAPE, KEY_P:
                    pause_down.emit()
        return
    if not _show_touch:
        return
    if event is InputEventScreenTouch:
        var t := make_input_local(event) as InputEventScreenTouch
        if t.pressed:
            _touch_down(t.index, t.position)
        else:
            _touch_up(t.index)
    elif event is InputEventScreenDrag:
        var d := make_input_local(event) as InputEventScreenDrag
        if d.index == _joy_finger:
            _update_joy(d.position)


func _touch_down(finger: int, pos: Vector2) -> void:
    if _pause_finger == -1 and _hit(pos, _pause_c(), PAUSE_R):
        _pause_finger = finger
        pause_down.emit()
    elif _jump_finger == -1 and _hit(pos, _jump_c(), JUMP_R):
        _jump_finger = finger
        _jump_touch = true
        jump_down.emit()
    elif _dash_finger == -1 and _hit(pos, _dash_c(), DASH_R):
        _dash_finger = finger
        dash_down.emit()
    elif _magnet_finger == -1 and _hit(pos, _magnet_c(), MAGNET_R):
        _magnet_finger = finger
        magnet_down.emit()
    elif _joy_finger == -1 and pos.x < size.x * 0.5:
        _joy_finger = finger
        _joy_origin = pos
        _update_joy(pos)


func _touch_up(finger: int) -> void:
    if finger == _jump_finger:
        _jump_finger = -1
        _jump_touch = false
    if finger == _dash_finger:
        _dash_finger = -1
    if finger == _magnet_finger:
        _magnet_finger = -1
    if finger == _pause_finger:
        _pause_finger = -1
    if finger == _joy_finger:
        _joy_finger = -1
        _touch_axis = 0.0


func _update_joy(pos: Vector2) -> void:
    var v := pos - _joy_origin
    if v.length() > JOY_RADIUS:
        v = v.normalized() * JOY_RADIUS
    _joy_pos = _joy_origin + v
    var a: float = clampf(v.x / (JOY_RADIUS * 0.75), -1.0, 1.0)
    _touch_axis = 0.0 if absf(a) < DEADZONE else a


func _process(_delta: float) -> void:
    var key_axis: float = 0.0
    if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT):
        key_axis -= 1.0
    if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT):
        key_axis += 1.0
    axis = key_axis if key_axis != 0.0 else _touch_axis
    jump_held = _jump_touch or Input.is_physical_key_pressed(KEY_SPACE) \
        or Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP)
    if _show_touch:
        queue_redraw()


func _draw_sprite(tex_name: String, c: Vector2, r: float, alpha: float) -> void:
    var t := Ui.tex(tex_name)
    var box := r * 2.0
    var k := minf(box / float(t.get_width()), box / float(t.get_height()))
    var sz := Vector2(float(t.get_width()), float(t.get_height())) * k
    draw_texture_rect(t, Rect2(c - sz * 0.5, sz), false, Color(1, 1, 1, alpha))


func _draw() -> void:
    if not _show_touch:
        return
    var center := _joy_origin if _joy_finger != -1 else _idle_joy_c()
    var knob := _joy_pos if _joy_finger != -1 else center
    draw_circle(center, JOY_RADIUS, Color(1, 1, 1, 0.08))
    draw_arc(center, JOY_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.35), 3.0)
    _draw_sprite("joy_knob", knob, 58.0, 0.85)
    _draw_sprite("jump_btn", _jump_c(), JUMP_R, 0.95 if _jump_touch else 0.75)
    var dash_ready: bool = player == null or player.dash_cd <= 0.0
    var magnet_ready: bool = player == null or (player.magnet_cd <= 0.0 and player.magnet_left <= 0.0)
    _draw_sprite("dash_btn", _dash_c(), DASH_R, 0.8 if dash_ready else 0.3)
    _draw_sprite("magnet_btn", _magnet_c(), MAGNET_R, 0.8 if magnet_ready else 0.3)
    _draw_sprite("blob_pause", _pause_c(), PAUSE_R, 0.8)

extends CharacterBody2D
# The blob. Placeholder art: no blob sprite was supplied, so it is drawn with draw_* calls (see _draw).
# Tuning values below are UNCALIBRATED starting points, not measured from the original game.

signal hp_changed(hp: float, max_hp: float)
signal died

const GRAVITY := 1800.0
const MAX_FALL := 1400.0
const MOVE_SPEED := 340.0
const ACCEL := 2600.0
const FRICTION := 2400.0
const JUMP_SPEED := 780.0
const SHORT_HOP := 280.0
const COYOTE := 0.10
const JUMP_BUFFER := 0.12
const DASH_SPEED := 760.0
const DASH_TIME := 0.18
const DASH_COOLDOWN := 0.8
const MAGNET_TIME := 3.0
const MAGNET_COOLDOWN := 8.0
const MAGNET_RANGE := 380.0
const INVULN_TIME := 1.0
const BASE_HP := 100.0
const BASE_RADIUS := 26.0
const MAX_GROWTH := 6

var controls = null          # object exposing axis: float and jump_held: bool
var hp: float = BASE_HP
var max_hp: float = BASE_HP
var growth: int = 0
var radius: float = BASE_RADIUS
var facing: float = 1.0
var dead: bool = false
var invuln_left: float = 0.0
var dash_left: float = 0.0
var dash_cd: float = 0.0
var magnet_left: float = 0.0
var magnet_cd: float = 0.0

var _dash_dir: float = 1.0
var _coyote_left: float = 0.0
var _buffer_left: float = 0.0
var _shape: CircleShape2D
var _t: float = 0.0


func _ready() -> void:
    collision_layer = 2
    collision_mask = 1
    floor_snap_length = 8.0
    var cs := CollisionShape2D.new()
    _shape = CircleShape2D.new()
    _shape.radius = radius
    cs.shape = _shape
    add_child(cs)


func request_jump() -> void:
    _buffer_left = JUMP_BUFFER


func request_dash() -> void:
    if dead or dash_cd > 0.0 or dash_left > 0.0:
        return
    _dash_dir = facing
    dash_left = DASH_TIME
    dash_cd = DASH_COOLDOWN


func request_magnet() -> void:
    if dead or magnet_cd > 0.0 or magnet_left > 0.0:
        return
    magnet_left = MAGNET_TIME
    magnet_cd = MAGNET_COOLDOWN


func take_damage(amount: float) -> void:
    if dead or invuln_left > 0.0:
        return
    hp = maxf(0.0, hp - amount)
    invuln_left = INVULN_TIME
    velocity.y = -520.0
    hp_changed.emit(hp, max_hp)
    if hp <= 0.0:
        die()


func heal(amount: float) -> void:
    if dead:
        return
    hp = minf(max_hp, hp + amount)
    hp_changed.emit(hp, max_hp)


func grow() -> void:
    growth = mini(growth + 1, MAX_GROWTH)
    var old_radius := radius
    radius = BASE_RADIUS + 1.5 * float(growth)
    max_hp = BASE_HP + 10.0 * float(growth)
    _shape.radius = radius
    global_position.y -= (radius - old_radius)   # keep the blob from sinking into the floor
    heal(25.0)


func die() -> void:
    if dead:
        return
    dead = true
    hp = 0.0
    velocity = Vector2.ZERO
    hp_changed.emit(hp, max_hp)
    died.emit()


func _physics_process(delta: float) -> void:
    if dead:
        return
    _t += delta
    invuln_left = maxf(0.0, invuln_left - delta)
    dash_cd = maxf(0.0, dash_cd - delta)
    magnet_cd = maxf(0.0, magnet_cd - delta)
    magnet_left = maxf(0.0, magnet_left - delta)
    _buffer_left = maxf(0.0, _buffer_left - delta)

    var axis: float = 0.0
    var jump_held: bool = false
    if controls != null:
        axis = controls.axis
        jump_held = controls.jump_held
    if absf(axis) > 0.05:
        facing = signf(axis)

    if is_on_floor():
        _coyote_left = COYOTE
    else:
        _coyote_left = maxf(0.0, _coyote_left - delta)

    if dash_left > 0.0:
        dash_left -= delta
        velocity.x = _dash_dir * DASH_SPEED
        velocity.y = 0.0
    else:
        var target: float = axis * MOVE_SPEED
        var rate: float = ACCEL if absf(axis) > 0.05 else FRICTION
        velocity.x = move_toward(velocity.x, target, rate * delta)
        velocity.y = minf(velocity.y + GRAVITY * delta, MAX_FALL)
        if _buffer_left > 0.0 and _coyote_left > 0.0:
            velocity.y = -JUMP_SPEED
            _buffer_left = 0.0
            _coyote_left = 0.0
        if velocity.y < -SHORT_HOP and not jump_held:
            velocity.y = -SHORT_HOP
    move_and_slide()
    queue_redraw()


func _draw() -> void:
    var a: float = 1.0
    if invuln_left > 0.0 and int(_t * 20.0) % 2 == 0:
        a = 0.45
    var sx: float = 1.0
    var sy: float = 1.0
    if dash_left > 0.0:
        sx = 1.3
        sy = 0.8
    else:
        sy = 1.0 + clampf(absf(velocity.y) / MAX_FALL, 0.0, 0.25)
        sx = 1.0 - (sy - 1.0) * 0.6
    draw_set_transform(Vector2(0.0, radius * (1.0 - sy)), 0.0, Vector2(sx, sy))
    draw_circle(Vector2.ZERO, radius, Color(0.66, 0.88, 0.05, a))
    draw_circle(Vector2(0.0, radius * 0.35), radius * 0.6, Color(0.5, 0.72, 0.02, a * 0.5))
    draw_arc(Vector2.ZERO, radius - 1.5, 0.0, TAU, 40, Color(1.0, 0.95, 0.15, a), 3.0)
    var eye := Vector2(facing * radius * 0.28, -radius * 0.15)
    var er := radius * 0.42
    draw_circle(eye, er, Color(0.93, 0.3, 0.6, a))
    draw_circle(eye + Vector2(facing * er * 0.2, 0.0), er * 0.55, Color(0.2, 0.02, 0.1, a))
    draw_circle(eye + Vector2(facing * er * 0.05, -er * 0.3), er * 0.18, Color(1, 1, 1, a))
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
    if magnet_left > 0.0:
        draw_arc(Vector2.ZERO, MAGNET_RANGE * (0.85 + 0.15 * sin(_t * 8.0)), 0.0, TAU, 64, Color(0.9, 0.3, 0.3, 0.3), 4.0)

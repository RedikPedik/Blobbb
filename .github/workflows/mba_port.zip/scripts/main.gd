extends Node
# Screen manager: menu, story-mode level list, options, local results, and the running level.

const MenuScreen = preload("res://scripts/menu_screen.gd")
const LevelSelectScreen = preload("res://scripts/level_select_screen.gd")
const OptionsScreen = preload("res://scripts/options_screen.gd")
const BoardsScreen = preload("res://scripts/boards_screen.gd")
const LevelScript = preload("res://scripts/level.gd")

var _current: Node = null
var _on_menu: bool = false


func _ready() -> void:
    get_tree().set_auto_accept_quit(true)
    show_menu()


func _swap(n: Node) -> void:
    get_tree().paused = false
    if _current != null:
        remove_child(_current)
        _current.queue_free()
    _current = n
    add_child(n)


func show_menu() -> void:
    var s := MenuScreen.new()
    s.story_pressed.connect(show_level_select)
    s.options_pressed.connect(show_options)
    s.boards_pressed.connect(show_boards)
    s.quit_pressed.connect(func(): get_tree().quit())
    _on_menu = true
    _swap(s)


func show_level_select() -> void:
    var s := LevelSelectScreen.new()
    s.level_chosen.connect(start_level)
    s.back_pressed.connect(show_menu)
    _on_menu = false
    _swap(s)


func show_options() -> void:
    var s := OptionsScreen.new()
    s.back_pressed.connect(show_menu)
    _on_menu = false
    _swap(s)


func show_boards() -> void:
    var s := BoardsScreen.new()
    s.back_pressed.connect(show_menu)
    _on_menu = false
    _swap(s)


func start_level(index: int) -> void:
    if index < 0 or index >= Game.unlocked:
        show_level_select()
        return
    var lv := LevelScript.new()
    lv.level_index = index
    lv.request_level.connect(start_level)
    lv.request_menu.connect(show_level_select)
    _on_menu = false
    _swap(lv)


func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        if _on_menu:
            get_tree().quit()
        elif _current != null and _current.has_method("on_back_pressed"):
            _current.on_back_pressed()
        else:
            show_menu()

extends Node2D
# Collectible. Overlap is tested by the level with plain circle maths, so this node only draws itself.

const Ui = preload("res://scripts/ui.gd")

enum Kind { COIN, FOOD, BLOB }

var kind: int = Kind.COIN
var radius: float = 16.0
var collected: bool = false
var _t: float = 0.0
var _phase: float = 0.0


func setup(k: int, pos: Vector2) -> void:
    kind = k
    position = pos
    _phase = fmod(pos.x * 0.013, TAU)
    match k:
        Kind.COIN:
            radius = 16.0
        Kind.FOOD:
            radius = 20.0
        Kind.BLOB:
            radius = 26.0


func _process(delta: float) -> void:
    _t += delta
    queue_redraw()


func _draw() -> void:
    var bob := sin(_t * 3.0 + _phase) * 4.0
    match kind:
        Kind.COIN:
            _draw_sprite("ico_coin", radius * 2.0, bob)
        Kind.BLOB:
            _draw_sprite("ico_blob", radius * 2.0 * (1.0 + 0.06 * sin(_t * 5.0)), bob)
        Kind.FOOD:
            var r := radius
            draw_rect(Rect2(-r, -r + bob, r * 2.0, r * 2.0), Color(0.55, 0.33, 0.15))
            draw_rect(Rect2(-r, -r + bob, r * 2.0, r * 2.0), Color(0.3, 0.17, 0.07), false, 3.0)
            draw_line(Vector2(-r, -r + bob), Vector2(r, r + bob), Color(0.3, 0.17, 0.07), 3.0)
            draw_line(Vector2(r, -r + bob), Vector2(-r, r + bob), Color(0.3, 0.17, 0.07), 3.0)


func _draw_sprite(tex_name: String, height: float, bob: float) -> void:
    var t := Ui.tex(tex_name)
    var w := height * float(t.get_width()) / float(t.get_height())
    draw_texture_rect(t, Rect2(-w * 0.5, -height * 0.5 + bob, w, height), false)

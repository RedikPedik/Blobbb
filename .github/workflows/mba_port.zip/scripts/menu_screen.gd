extends Control

signal story_pressed
signal options_pressed
signal boards_pressed
signal quit_pressed

const Ui = preload("res://scripts/ui.gd")
const Backdrop = preload("res://scripts/backdrop.gd")


func _ready() -> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)
    var bg := Backdrop.new()
    bg.mode = 1
    add_child(bg)

    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 70)
    row.alignment = BoxContainer.ALIGNMENT_CENTER
    center.add_child(row)

    var logo := TextureRect.new()
    logo.texture = Ui.tex("logo")
    logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    logo.custom_minimum_size = Vector2(380.0, 540.0)
    row.add_child(logo)

    var col := VBoxContainer.new()
    col.alignment = BoxContainer.ALIGNMENT_CENTER
    col.add_theme_constant_override("separation", 24)
    row.add_child(col)
    col.add_child(Ui.tex_button("btn_story", 104.0, func(): story_pressed.emit()))
    col.add_child(Ui.tex_button("btn_options", 104.0, func(): options_pressed.emit()))
    col.add_child(Ui.tex_button("btn_leaderboards", 104.0, func(): boards_pressed.emit()))
    if not OS.has_feature("mobile"):
        col.add_child(Ui.tex_button("btn_quit", 104.0, func(): quit_pressed.emit()))

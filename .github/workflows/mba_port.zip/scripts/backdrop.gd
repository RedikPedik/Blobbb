extends Control
# Screen-space background. mode 0: night gradient with a scrolling skyline (in-game). mode 1: sunburst (menus).

var mode: int = 0
var scroll: float = 0.0
var _t: float = 0.0


func _ready() -> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE


func _process(delta: float) -> void:
    _t += delta
    queue_redraw()


func _draw() -> void:
    var s := size
    var top := Color(0.12, 0.05, 0.28)
    var bot := Color(0.33, 0.12, 0.38)
    draw_polygon(
        PackedVector2Array([Vector2(0, 0), Vector2(s.x, 0), Vector2(s.x, s.y), Vector2(0, s.y)]),
        PackedColorArray([top, top, bot, bot]))
    if mode == 1:
        _draw_rays(s)
    else:
        _draw_skyline(s)


func _draw_rays(s: Vector2) -> void:
    var c := Vector2(s.x * 0.5, s.y * 0.52)
    var reach := s.length()
    var wedges := 16
    for i in range(0, wedges, 2):
        var a0 := TAU * float(i) / float(wedges) + _t * 0.04
        var a1 := TAU * float(i + 1) / float(wedges) + _t * 0.04
        draw_colored_polygon(
            PackedVector2Array([c, c + Vector2.from_angle(a0) * reach, c + Vector2.from_angle(a1) * reach]),
            Color(0.38, 0.15, 0.8, 0.28))


func _draw_skyline(s: Vector2) -> void:
    var pitch := 150.0
    var shift := scroll * 0.2
    var first := floori(shift / pitch) - 1
    var count := int(s.x / pitch) + 4
    for k in range(count):
        var idx := first + k
        var h := 90.0 + float(absi(idx * 7919) % 11) * 16.0
        var x := float(idx) * pitch - shift
        draw_rect(Rect2(x, s.y - h - 40.0, 120.0, h + 40.0), Color(0.2, 0.08, 0.3, 1.0))

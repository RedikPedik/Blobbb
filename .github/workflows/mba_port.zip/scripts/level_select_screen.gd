extends Control

signal level_chosen(index: int)
signal back_pressed

const Ui = preload("res://scripts/ui.gd")
const Backdrop = preload("res://scripts/backdrop.gd")
const LevelData = preload("res://scripts/level_data.gd")


func _ready() -> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)
    var bg := Backdrop.new()
    bg.mode = 1
    add_child(bg)

    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var col := VBoxContainer.new()
    col.alignment = BoxContainer.ALIGNMENT_CENTER
    col.add_theme_constant_override("separation", 36)
    center.add_child(col)

    var title := Ui.label("Story Mode", 72, Color(0.75, 0.95, 0.1))
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    col.add_child(title)

    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 36)
    row.alignment = BoxContainer.ALIGNMENT_CENTER
    col.add_child(row)
    for i in range(LevelData.count()):
        var d: Dictionary = LevelData.get_level(i)
        var card := VBoxContainer.new()
        card.add_theme_constant_override("separation", 10)
        row.add_child(card)
        var unlocked: bool = i < Game.unlocked
        var idx := i
        card.add_child(Ui.lime_button("%d. %s" % [i + 1, d["name"]], Vector2(300.0, 110.0),
            func(): level_chosen.emit(idx), unlocked))
        var info := "Locked"
        if unlocked:
            info = "Best: %d / %d coins" % [int(Game.best_coins.get(i, 0)), d["coins"].size()]
        var l := Ui.label(info, 24)
        l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        card.add_child(l)

    col.add_child(Ui.tex_button("btn_back", 84.0, func(): back_pressed.emit()))
    col.get_child(col.get_child_count() - 1).size_flags_horizontal = Control.SIZE_SHRINK_CENTER

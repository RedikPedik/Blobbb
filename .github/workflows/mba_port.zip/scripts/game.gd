extends Node
# Autoload "Game": progress and local best results, stored in user://progress.cfg.

const SAVE_PATH := "user://progress.cfg"
const LevelData = preload("res://scripts/level_data.gd")

var unlocked: int = 1                 # number of unlocked levels (levels 0 .. unlocked-1)
var best_coins: Dictionary = {}       # level index -> int
var best_time: Dictionary = {}        # level index -> float seconds


func _ready() -> void:
    load_progress()


func load_progress() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(SAVE_PATH) != OK:
        return
    unlocked = clampi(int(cfg.get_value("progress", "unlocked", 1)), 1, LevelData.count())
    for i in range(LevelData.count()):
        var key := str(i)
        if cfg.has_section_key("best_coins", key):
            best_coins[i] = int(cfg.get_value("best_coins", key))
        if cfg.has_section_key("best_time", key):
            best_time[i] = float(cfg.get_value("best_time", key))


func save_progress() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("progress", "unlocked", unlocked)
    for i in best_coins.keys():
        cfg.set_value("best_coins", str(i), best_coins[i])
    for i in best_time.keys():
        cfg.set_value("best_time", str(i), best_time[i])
    var err := cfg.save(SAVE_PATH)
    if err != OK:
        push_warning("Could not save progress (error %d)" % err)


func record_result(level: int, coins: int, seconds: float) -> void:
    if not best_coins.has(level) or coins > int(best_coins[level]):
        best_coins[level] = coins
    if not best_time.has(level) or seconds < float(best_time[level]):
        best_time[level] = seconds
    unlocked = clampi(maxi(unlocked, level + 2), 1, LevelData.count())
    save_progress()


func reset_progress() -> void:
    unlocked = 1
    best_coins.clear()
    best_time.clear()
    save_progress()


func format_time(seconds: float) -> String:
    var total := int(seconds)
    return "%d:%02d" % [floori(total / 60.0), total % 60]

extends Node2D
# One playable level: builds terrain, pickups, player, camera, HUD, touch controls and the pause / result overlays
# from LevelData. Overlap tests use circle-vs-rect maths (circle_hits_rect) instead of physics areas.

signal request_level(index: int)
signal request_menu

const LevelData = preload("res://scripts/level_data.gd")
const Ui = preload("res://scripts/ui.gd")
const Backdrop = preload("res://scripts/backdrop.gd")
const PlayerScript = preload("res://scripts/player.gd")
const PickupScript = preload("res://scripts/pickup.gd")
const ControlsScript = preload("res://scripts/controls.gd")
const HudScript = preload("res://scripts/hud.gd")

const SPIKE_DAMAGE := 34.0
const FALL_Y := 820.0
const MAGNET_PULL := 760.0

var level_index: int = 0

var data: Dictionary = {}
var player
var controls
var hud
var backdrop
var camera: Camera2D
var pickups: Array = []
var spike_rects: Array = []
var goal: Rect2
var coins: int = 0
var coins_total: int = 0
var rescued: int = 0
var rescue_total: int = 0
var elapsed: float = 0.0
var state: String = "playing"     # playing | won | lost

var _ui: CanvasLayer
var _overlay: Control
var _goal_hint_cool: float = 0.0


static func circle_hits_rect(c: Vector2, r: float, rect: Rect2) -> bool:
    var nx: float = clampf(c.x, rect.position.x, rect.end.x)
    var ny: float = clampf(c.y, rect.position.y, rect.end.y)
    return c.distance_squared_to(Vector2(nx, ny)) <= r * r


func _ready() -> void:
    data = LevelData.get_level(level_index)
    var width: float = data["width"]
    goal = data["goal"]
    spike_rects = data["spikes"]

    var back_layer := CanvasLayer.new()
    back_layer.layer = -10
    add_child(back_layer)
    backdrop = Backdrop.new()
    back_layer.add_child(backdrop)

    for r in data["ground"]:
        _add_solid(r)
    for r in data["platforms"]:
        _add_solid(r)
    _add_solid(Rect2(-60.0, -400.0, 60.0, 1600.0))
    _add_solid(Rect2(width, -400.0, 60.0, 1600.0))

    for v in data["coins"]:
        _spawn(PickupScript.Kind.COIN, v)
    for v in data["food"]:
        _spawn(PickupScript.Kind.FOOD, v)
    for v in data["blobs"]:
        _spawn(PickupScript.Kind.BLOB, v)
    coins_total = data["coins"].size()
    rescue_total = data["blobs"].size()

    player = PlayerScript.new()
    player.position = data["start"]
    add_child(player)
    camera = Camera2D.new()
    camera.limit_left = 0
    camera.limit_right = int(width)
    camera.limit_top = 0
    camera.limit_bottom = 720
    camera.position_smoothing_enabled = true
    camera.position_smoothing_speed = 8.0
    player.add_child(camera)

    _ui = CanvasLayer.new()
    _ui.layer = 10
    add_child(_ui)
    hud = HudScript.new()
    _ui.add_child(hud)
    controls = ControlsScript.new()
    controls.player = player
    _ui.add_child(controls)

    controls.jump_down.connect(player.request_jump)
    controls.dash_down.connect(player.request_dash)
    controls.magnet_down.connect(player.request_magnet)
    controls.pause_down.connect(_on_pause_pressed)
    player.controls = controls
    player.hp_changed.connect(hud.set_hp)
    player.died.connect(_on_player_died)

    hud.set_coins(0)
    hud.set_blobs(0, rescue_total)
    hud.show_hint("Rescue all %d blobs, then reach the exit." % rescue_total, 5.0)


func _add_solid(r: Rect2) -> void:
    var body := StaticBody2D.new()
    body.collision_layer = 1
    body.collision_mask = 0
    body.position = r.position + r.size * 0.5
    var cs := CollisionShape2D.new()
    var shape := RectangleShape2D.new()
    shape.size = r.size
    cs.shape = shape
    body.add_child(cs)
    add_child(body)


func _spawn(kind: int, pos: Vector2) -> void:
    var p := PickupScript.new()
    p.setup(kind, pos)
    add_child(p)
    pickups.append(p)


func _physics_process(delta: float) -> void:
    backdrop.scroll = camera.get_screen_center_position().x
    if state != "playing":
        return
    elapsed += delta
    _goal_hint_cool = maxf(0.0, _goal_hint_cool - delta)
    var pp: Vector2 = player.global_position
    var pr: float = player.radius

    if player.magnet_left > 0.0:
        for p in pickups:
            if p.kind == PickupScript.Kind.BLOB:
                continue
            var to_player: Vector2 = pp - p.global_position
            if to_player.length() < player.MAGNET_RANGE:
                p.global_position += to_player.normalized() * minf(MAGNET_PULL * delta, to_player.length())

    for p in pickups.duplicate():
        if p.global_position.distance_to(pp) <= pr + p.radius:
            _collect(p)

    for r in spike_rects:
        if circle_hits_rect(pp, pr * 0.85, r):
            player.take_damage(SPIKE_DAMAGE)
            break

    if circle_hits_rect(pp, pr, goal):
        if rescued >= rescue_total:
            _win()
        elif _goal_hint_cool <= 0.0:
            hud.show_hint("Rescue all blobs first: %d / %d" % [rescued, rescue_total], 2.5)
            _goal_hint_cool = 3.0

    if pp.y > FALL_Y:
        player.die()


func _collect(p: Node2D) -> void:
    if p.collected:
        return
    p.collected = true
    pickups.erase(p)
    match p.kind:
        PickupScript.Kind.COIN:
            coins += 1
            hud.set_coins(coins)
        PickupScript.Kind.FOOD:
            player.grow()
        PickupScript.Kind.BLOB:
            rescued += 1
            hud.set_blobs(rescued, rescue_total)
            queue_redraw()
            if rescued >= rescue_total:
                hud.show_hint("All blobs rescued! Head for the exit.", 3.0)
    p.queue_free()


func _draw() -> void:
    for r in data["ground"]:
        draw_rect(r, Color(0.23, 0.11, 0.29))
        draw_rect(Rect2(r.position.x, r.position.y, r.size.x, 10.0), Color(0.62, 0.8, 0.05))
        draw_rect(Rect2(r.position.x, r.position.y + 10.0, r.size.x, 5.0), Color(0.4, 0.55, 0.04))
    for r in data["platforms"]:
        draw_rect(r, Color(0.33, 0.16, 0.38))
        draw_rect(Rect2(r.position.x, r.position.y, r.size.x, 8.0), Color(0.75, 0.9, 0.05))
        draw_rect(r, Color(0.15, 0.06, 0.2), false, 2.0)
    for r in spike_rects:
        var n: int = maxi(1, roundi(r.size.x / 25.0))
        var tw: float = r.size.x / float(n)
        for k in range(n):
            var x0: float = r.position.x + tw * float(k)
            draw_colored_polygon(PackedVector2Array([
                Vector2(x0, r.end.y), Vector2(x0 + tw, r.end.y), Vector2(x0 + tw * 0.5, r.position.y)]),
                Color(0.78, 0.2, 0.7))
    var is_open: bool = rescued >= rescue_total
    var door_col := Color(0.4, 1.0, 0.4, 0.55) if is_open else Color(0.6, 0.6, 0.6, 0.45)
    draw_rect(goal, door_col)
    draw_rect(goal, Color(1, 1, 0.3, 0.9) if is_open else Color(0.7, 0.7, 0.7, 0.8), false, 4.0)
    var t := Ui.tex("blob_exit")
    var w: float = 110.0
    var h: float = w * float(t.get_height()) / float(t.get_width())
    draw_texture_rect(t, Rect2(goal.position.x + goal.size.x * 0.5 - w * 0.5, goal.position.y - h - 6.0, w, h),
        false, Color(1, 1, 1, 1.0) if is_open else Color(0.6, 0.6, 0.6, 0.8))


func _show_overlay(title: String, body: String, buttons: Array) -> void:
    if _overlay != null:
        _overlay.queue_free()
    _overlay = Control.new()
    _overlay.process_mode = Node.PROCESS_MODE_ALWAYS
    _overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
    _ui.add_child(_overlay)
    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.62)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    _overlay.add_child(dim)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    _overlay.add_child(center)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 20)
    col.alignment = BoxContainer.ALIGNMENT_CENTER
    center.add_child(col)
    var tl := Ui.label(title, 64, Color(0.75, 0.95, 0.1))
    tl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    col.add_child(tl)
    if body != "":
        var bl := Ui.label(body, 32)
        bl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        col.add_child(bl)
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 24)
    row.alignment = BoxContainer.ALIGNMENT_CENTER
    col.add_child(row)
    for b in buttons:
        row.add_child(Ui.tex_button(b[0], 96.0, b[1]))


func _on_pause_pressed() -> void:
    if state != "playing" or get_tree().paused:
        return
    controls.reset()
    get_tree().paused = true
    _show_overlay("Paused", "", [["btn_resume", _resume], ["btn_retry", _retry], ["btn_menu", _to_menu]])


func _resume() -> void:
    get_tree().paused = false
    if _overlay != null:
        _overlay.queue_free()
        _overlay = null
    controls.reset()


func _retry() -> void:
    get_tree().paused = false
    request_level.emit(level_index)


func _to_menu() -> void:
    get_tree().paused = false
    request_menu.emit()


func _next() -> void:
    get_tree().paused = false
    request_level.emit(level_index + 1)


func on_back_pressed() -> void:
    if get_tree().paused:
        _resume()
    elif state == "playing":
        _on_pause_pressed()
    else:
        _to_menu()


func _on_player_died() -> void:
    if state != "playing":
        return
    state = "lost"
    controls.reset()
    _show_overlay("Blob down!", "Coins: %d   Blobs: %d/%d" % [coins, rescued, rescue_total],
        [["btn_retry", _retry], ["btn_menu", _to_menu]])


func _win() -> void:
    if state != "playing":
        return
    state = "won"
    controls.reset()
    Game.record_result(level_index, coins, elapsed)
    var body := "Coins: %d / %d\nBlobs: %d / %d\nTime: %s" % [coins, coins_total, rescued, rescue_total,
        Game.format_time(elapsed)]
    var buttons: Array = []
    if level_index + 1 < LevelData.count():
        buttons.append(["btn_next", _next])
    buttons.append(["btn_retry", _retry])
    buttons.append(["btn_menu", _to_menu])
    _show_overlay("Level Complete!", body, buttons)

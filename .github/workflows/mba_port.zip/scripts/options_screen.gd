extends Control

signal back_pressed

const Ui = preload("res://scripts/ui.gd")
const Backdrop = preload("res://scripts/backdrop.gd")

var _reset_armed: bool = false
var _reset_button: Button


func _ready() -> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)
    var bg := Backdrop.new()
    bg.mode = 1
    add_child(bg)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var col := VBoxContainer.new()
    col.alignment = BoxContainer.ALIGNMENT_CENTER
    col.add_theme_constant_override("separation", 28)
    center.add_child(col)

    var title := Ui.label("Options", 72, Color(0.75, 0.95, 0.1))
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    col.add_child(title)

    var help := Ui.label("Touch: drag on the left half to move. Jump, dash and magnet buttons are on the right.\n"
        + "Keyboard: A/D or arrows move, Space jump, Shift dash, Q magnet, Esc pause.\n"
        + "Collect crates to grow and heal. Spikes hurt. Rescue every blob to open the exit.", 26)
    help.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    col.add_child(help)

    _reset_button = Ui.lime_button("Reset progress", Vector2(360.0, 90.0), _on_reset)
    _reset_button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    col.add_child(_reset_button)

    var back := Ui.tex_button("btn_back", 84.0, func(): back_pressed.emit())
    back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    col.add_child(back)


func _on_reset() -> void:
    if not _reset_armed:
        _reset_armed = true
        _reset_button.text = "Tap again to confirm"
        return
    Game.reset_progress()
    _reset_armed = false
    _reset_button.text = "Progress reset"

extends Control
# "Leaderboards": local best results only. No online service is implemented.

signal back_pressed

const Ui = preload("res://scripts/ui.gd")
const Backdrop = preload("res://scripts/backdrop.gd")
const LevelData = preload("res://scripts/level_data.gd")


func _ready() -> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)
    var bg := Backdrop.new()
    bg.mode = 1
    add_child(bg)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var col := VBoxContainer.new()
    col.alignment = BoxContainer.ALIGNMENT_CENTER
    col.add_theme_constant_override("separation", 22)
    center.add_child(col)

    var title := Ui.label("Best Results (this device)", 60, Color(0.75, 0.95, 0.1))
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    col.add_child(title)

    for i in range(LevelData.count()):
        var d: Dictionary = LevelData.get_level(i)
        var text := "%d. %s: not completed yet" % [i + 1, d["name"]]
        if Game.best_time.has(i):
            text = "%d. %s: %d / %d coins, best time %s" % [i + 1, d["name"], int(Game.best_coins.get(i, 0)),
                d["coins"].size(), Game.format_time(float(Game.best_time[i]))]
        var l := Ui.label(text, 32)
        l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        col.add_child(l)

    var back := Ui.tex_button("btn_back", 84.0, func(): back_pressed.emit())
    back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    col.add_child(back)

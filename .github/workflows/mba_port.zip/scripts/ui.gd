extends RefCounted
# Small helpers for building the menus from code. Sprites live in res://assets/ui.

static var _cache: Dictionary = {}


static func tex(tex_name: String) -> Texture2D:
    if not _cache.has(tex_name):
        _cache[tex_name] = load("res://assets/ui/%s.png" % tex_name)
    return _cache[tex_name]


static func tex_button(tex_name: String, height: float, cb: Callable) -> TextureButton:
    var t := tex(tex_name)
    var b := TextureButton.new()
    b.texture_normal = t
    b.ignore_texture_size = true
    b.stretch_mode = TextureButton.STRETCH_SCALE
    var aspect := float(t.get_width()) / float(t.get_height())
    b.custom_minimum_size = Vector2(height * aspect, height)
    b.pressed.connect(cb)
    b.button_down.connect(func(): b.modulate = Color(0.75, 0.75, 0.75))
    b.button_up.connect(func(): b.modulate = Color(1, 1, 1))
    return b


static func label(text: String, font_size: int, color: Color = Color.WHITE, outline: bool = true) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", font_size)
    l.add_theme_color_override("font_color", color)
    if outline:
        l.add_theme_constant_override("outline_size", maxi(2, roundi(font_size * 0.15)))
        l.add_theme_color_override("font_outline_color", Color(0.2, 0.05, 0.25))
    return l


static func _lime_style(bg: Color, border: Color) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = bg
    s.border_color = border
    s.set_border_width_all(4)
    s.set_corner_radius_all(26)
    s.set_content_margin_all(12)
    return s


static func lime_button(text: String, min_size: Vector2, cb: Callable, enabled: bool = true) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = min_size
    b.disabled = not enabled
    b.add_theme_font_size_override("font_size", 30)
    var dark_red := Color(0.45, 0.04, 0.1)
    b.add_theme_color_override("font_color", dark_red)
    b.add_theme_color_override("font_hover_color", dark_red)
    b.add_theme_color_override("font_pressed_color", dark_red)
    b.add_theme_color_override("font_disabled_color", Color(0.35, 0.3, 0.38))
    b.add_theme_stylebox_override("normal", _lime_style(Color(0.75, 0.9, 0.05), Color(1, 1, 0.1)))
    b.add_theme_stylebox_override("hover", _lime_style(Color(0.82, 0.95, 0.15), Color(1, 1, 0.3)))
    b.add_theme_stylebox_override("pressed", _lime_style(Color(0.6, 0.75, 0.03), Color(0.9, 0.9, 0.05)))
    b.add_theme_stylebox_override("disabled", _lime_style(Color(0.35, 0.3, 0.4), Color(0.5, 0.45, 0.55)))
    b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    b.pressed.connect(cb)
    return b

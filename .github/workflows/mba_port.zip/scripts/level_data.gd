extends RefCounted
# Level layouts. World units are pixels, y grows downward, ground surface is y=600, the camera shows y 0..720.
# Reach limits used when laying these out (derived from player.gd constants, see README): jump rise ~169 px,
# horizontal jump ~295 px. Platforms are kept to <=150 px rise and <=250 px gaps.
# These layouts are ORIGINAL; they are not copied from the original game.

static func count() -> int:
    return 3


static func get_level(i: int) -> Dictionary:
    match i:
        0:
            return _level_1()
        1:
            return _level_2()
        _:
            return _level_3()


static func _arc(x: float, y: float, n: int, dx: float, height: float) -> PackedVector2Array:
    var out := PackedVector2Array()
    for k in range(n):
        var t := float(k) / float(maxi(n - 1, 1))
        out.append(Vector2(x + dx * k, y - height * 4.0 * t * (1.0 - t)))
    return out


static func _row(x: float, y: float, n: int, dx: float) -> PackedVector2Array:
    var out := PackedVector2Array()
    for k in range(n):
        out.append(Vector2(x + dx * k, y))
    return out


static func _level_1() -> Dictionary:
    var coins := PackedVector2Array()
    coins.append_array(_arc(660, 540, 6, 38, 90))     # over first spikes
    coins.append_array(_arc(880, 540, 5, 60, 100))    # over gap 900-1100
    coins.append_array(_row(480, 435, 5, 40))         # on platform 1
    coins.append_array(_arc(1440, 540, 6, 38, 90))
    coins.append_array(_row(1580, 345, 5, 40))
    coins.append_array(_arc(1760, 540, 5, 60, 100))   # over gap 1800-2000
    coins.append_array(_row(2330, 435, 5, 45))
    coins.append_array(_arc(2560, 540, 7, 36, 90))
    return {
        "name": "Slime Alley",
        "width": 3300.0,
        "start": Vector2(80, 560),
        "ground": [Rect2(0, 600, 900, 200), Rect2(1100, 600, 700, 200), Rect2(2000, 600, 1300, 200)],
        "platforms": [Rect2(450, 470, 200, 24), Rect2(1250, 470, 200, 24), Rect2(1550, 380, 220, 24),
            Rect2(2300, 470, 250, 24), Rect2(2650, 380, 200, 24)],
        "spikes": [Rect2(700, 566, 100, 34), Rect2(1480, 566, 120, 34), Rect2(2600, 566, 90, 34),
            Rect2(2900, 566, 100, 34)],
        "coins": coins,
        "food": PackedVector2Array([Vector2(300, 575), Vector2(1200, 575), Vector2(2150, 575), Vector2(2425, 430)]),
        "blobs": PackedVector2Array([Vector2(550, 430), Vector2(1660, 340), Vector2(2750, 340)]),
        "goal": Rect2(3150, 520, 70, 80),
    }


static func _level_2() -> Dictionary:
    var coins := PackedVector2Array()
    coins.append_array(_arc(320, 540, 6, 38, 90))
    coins.append_array(_arc(660, 520, 5, 55, 90))      # over gap 700-900
    coins.append_array(_row(1010, 435, 4, 40))
    coins.append_array(_row(1260, 335, 4, 40))
    coins.append_array(_row(1520, 255, 5, 40))
    coins.append_array(_arc(1780, 540, 5, 60, 100))    # over gap 1800-2050
    coins.append_array(_row(2310, 435, 5, 40))
    coins.append_array(_arc(2500, 540, 4, 45, 90))
    coins.append_array(_arc(3050, 540, 8, 40, 100))
    return {
        "name": "Stairway to Slime",
        "width": 3600.0,
        "start": Vector2(80, 560),
        "ground": [Rect2(0, 600, 700, 200), Rect2(900, 600, 400, 200), Rect2(1500, 600, 300, 200),
            Rect2(2050, 600, 550, 200), Rect2(2850, 600, 750, 200)],
        "platforms": [Rect2(760, 520, 100, 24), Rect2(1000, 470, 160, 24), Rect2(1250, 370, 160, 24),
            Rect2(1500, 290, 200, 24), Rect2(1860, 500, 120, 24), Rect2(2300, 470, 200, 24),
            Rect2(2680, 520, 120, 24)],
        "spikes": [Rect2(350, 566, 100, 34), Rect2(1170, 566, 100, 34), Rect2(2510, 566, 90, 34),
            Rect2(3100, 566, 100, 34), Rect2(3300, 566, 100, 34)],
        "coins": coins,
        "food": PackedVector2Array([Vector2(200, 575), Vector2(950, 575), Vector2(1600, 575), Vector2(2200, 575),
            Vector2(3000, 575)]),
        "blobs": PackedVector2Array([Vector2(1330, 330), Vector2(1580, 250), Vector2(2400, 430)]),
        "goal": Rect2(3470, 520, 70, 80),
    }


static func _level_3() -> Dictionary:
    var coins := PackedVector2Array()
    coins.append_array(_arc(260, 540, 6, 38, 90))
    coins.append_array(_arc(480, 520, 6, 45, 90))
    coins.append_array(_arc(760, 540, 6, 38, 90))
    coins.append_array(_arc(960, 520, 6, 50, 90))
    coins.append_array(_row(1260, 455, 4, 40))
    coins.append_array(_row(1490, 355, 4, 40))
    coins.append_array(_row(1770, 265, 5, 40))
    coins.append_array(_arc(1650, 540, 7, 38, 100))
    coins.append_array(_arc(2380, 520, 6, 48, 90))
    coins.append_array(_arc(2660, 540, 6, 38, 90))
    coins.append_array(_arc(3260, 540, 6, 38, 90))
    coins.append_array(_arc(3460, 540, 6, 38, 90))
    return {
        "name": "Spike Gauntlet",
        "width": 3800.0,
        "start": Vector2(80, 560),
        "ground": [Rect2(0, 600, 500, 200), Rect2(700, 600, 300, 200), Rect2(1200, 600, 250, 200),
            Rect2(1650, 600, 250, 200), Rect2(2100, 600, 300, 200), Rect2(2600, 600, 300, 200),
            Rect2(3100, 600, 700, 200)],
        "platforms": [Rect2(540, 500, 120, 24), Rect2(1020, 500, 130, 24), Rect2(1250, 490, 150, 24),
            Rect2(1480, 390, 150, 24), Rect2(1750, 300, 180, 24), Rect2(2000, 420, 140, 24),
            Rect2(2450, 500, 120, 24), Rect2(2900, 500, 120, 24)],
        "spikes": [Rect2(300, 566, 90, 34), Rect2(800, 566, 100, 34), Rect2(1700, 566, 120, 34),
            Rect2(2200, 566, 100, 34), Rect2(2700, 566, 100, 34), Rect2(3300, 566, 100, 34),
            Rect2(3500, 566, 100, 34)],
        "coins": coins,
        "food": PackedVector2Array([Vector2(200, 575), Vector2(1300, 575), Vector2(1850, 575), Vector2(2350, 575),
            Vector2(2860, 575), Vector2(3200, 575)]),
        "blobs": PackedVector2Array([Vector2(590, 460), Vector2(1820, 260), Vector2(2970, 460)]),
        "goal": Rect2(3670, 520, 70, 80),
    }

extends Control
# In-game HUD: health bar (sprite split into empty frame + fill strip), coin and blob counters, hint panel.

const Ui = preload("res://scripts/ui.gd")
const UIMeta = preload("res://scripts/ui_meta.gd")

const BAR_SCALE := 0.55

var _bar: TextureProgressBar
var _coin_label: Label
var _blob_label: Label
var _hint_box: Control
var _hint_label: Label
var _hint_timer: Timer


func _ready() -> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE

    _bar = TextureProgressBar.new()
    _bar.texture_under = Ui.tex("bar_empty")
    _bar.texture_progress = Ui.tex("bar_fill")
    _bar.texture_progress_offset = Vector2(UIMeta.STRIP_X, UIMeta.STRIP_Y)
    _bar.fill_mode = TextureProgressBar.FILL_LEFT_TO_RIGHT
    _bar.min_value = 0.0
    _bar.max_value = 100.0
    _bar.value = 100.0
    _bar.scale = Vector2(BAR_SCALE, BAR_SCALE)
    _bar.position = Vector2(36.0, 14.0)
    add_child(_bar)

    _coin_label = _make_counter("ico_coin", Vector2(36.0, 84.0))
    _blob_label = _make_counter("ico_blob", Vector2(222.0, 84.0))

    var top := HBoxContainer.new()
    top.set_anchors_preset(Control.PRESET_TOP_WIDE)
    top.offset_top = 14.0
    top.alignment = BoxContainer.ALIGNMENT_CENTER
    top.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(top)
    _hint_box = Control.new()
    _hint_box.custom_minimum_size = Vector2(560.0, 130.0)
    _hint_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _hint_box.visible = false
    top.add_child(_hint_box)
    var bg := TextureRect.new()
    bg.texture = Ui.tex("hint_panel")
    bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    bg.stretch_mode = TextureRect.STRETCH_SCALE
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _hint_box.add_child(bg)
    _hint_label = Ui.label("", 26, Color(0.45, 0.04, 0.1), false)
    _hint_label.position = Vector2(112.0, 22.0)
    _hint_label.size = Vector2(420.0, 86.0)
    _hint_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _hint_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    _hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _hint_box.add_child(_hint_label)

    _hint_timer = Timer.new()
    _hint_timer.one_shot = true
    _hint_timer.timeout.connect(func(): _hint_box.visible = false)
    add_child(_hint_timer)


func _make_counter(icon_name: String, pos: Vector2) -> Label:
    var panel := Panel.new()
    var sb := StyleBoxFlat.new()
    sb.bg_color = Color(0.16, 0.06, 0.2, 0.88)
    sb.border_color = Color(0.4, 0.2, 0.5)
    sb.set_border_width_all(2)
    sb.set_corner_radius_all(22)
    panel.add_theme_stylebox_override("panel", sb)
    panel.position = pos
    panel.size = Vector2(170.0, 50.0)
    panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(panel)
    var icon := TextureRect.new()
    icon.texture = Ui.tex(icon_name)
    icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    icon.position = Vector2(8.0, 5.0)
    icon.size = Vector2(40.0, 40.0)
    icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
    panel.add_child(icon)
    var l := Ui.label("0", 28)
    l.position = Vector2(56.0, 4.0)
    l.size = Vector2(106.0, 42.0)
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    panel.add_child(l)
    return l


func set_hp(hp: float, max_hp: float) -> void:
    _bar.value = 100.0 * hp / maxf(max_hp, 1.0)


func set_coins(n: int) -> void:
    _coin_label.text = "x %d" % n


func set_blobs(n: int, total: int) -> void:
    _blob_label.text = "%d/%d" % [n, total]


func show_hint(text: String, seconds: float) -> void:
    _hint_label.text = text
    _hint_box.visible = true
    _hint_timer.start(seconds)
